@extends('layouts.app')

@section('content')
@include('layouts.google_analytics')

<main class="myMain adminMain mem">

</main>

@endsection