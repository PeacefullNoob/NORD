<div>
{{Form::submit($value,$attributes)}}
</div>