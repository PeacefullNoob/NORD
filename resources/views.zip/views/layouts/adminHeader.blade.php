<header id="header" class="hadm shadow-sm">


    <div class="myLogo">
        <a href="/admin">
            <img class="myLogoSvg" src="/images/Nord-logotype-bijela-bez slogana.svg">
        </a>
    </div>


    <div class="admin_menu" id="myMenu">
        <div class="mwdiv">
            <ul class="ulAd">
                <li> <a href="/" class="admin_menu__link" target="_blank"><i class="fa fa-fw fa-home"></i>Website Home</a></li>

                <li> <a href="/admin" class="admin_menu__link"><i class="fa fa-fw fa-home"></i>Home Panel</a></li>

                <li> <a href="/admin/albums/all_albums" class="admin_menu__link"><i class="fa fa-fw fa-home"></i>Svi Albumi</a></li>
                <li><a href="/admin/create" class="admin_menu__link"><i class="fa fa-upload"></i>+ Dodaj Album</a></li>
                <li> <a href="/admin/photos/upload_p/" class="admin_menu__link"><i class="fa fa-upload"></i>+ Dodaj media fajl</a></li>
            </ul>
        </div>
    </div>
</header>