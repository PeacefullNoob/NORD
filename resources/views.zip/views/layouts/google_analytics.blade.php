<div id="embed-api-auth-container"></div>
<div id="view-selector-container"></div>
<div id="main-chart-container"></div>
<div id="breakdown-chart-container"></div>